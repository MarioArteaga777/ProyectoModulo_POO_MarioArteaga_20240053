package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarioArteaga20240053ApplicationTests {

	@Test
	void contextLoads() {
	}

}
