package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Entities;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "TBPROVIDER")
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class ProveedoresEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seq_provider")
    @SequenceGenerator(name = "seq_provider",sequenceName = "seq_provider",allocationSize = 1)
    @Column(name = "PROVIDERID")
    private Long providerID;

    @Column(name = "PROVIDERNAME", unique = true)
    private String providerName;

    @Column(name = "PROVIDERPHONE")
    private String  providerPhone;

    @Column(name = "PROVIDERADDRESS")
    private String  providerAddress;

    @Column(name = "PROVIDEREMAIL",unique = true)
    private String   providerEmail;

    @Column(name = "PROVIDERCODE", unique = true)
    private String providerCode;

    @Column(name = "PROVIDERSTATUS")
    private Long  providerStatus ;

    @Column(name = "PROVIDERCOMMENTS")
      private String providerComments;

}
