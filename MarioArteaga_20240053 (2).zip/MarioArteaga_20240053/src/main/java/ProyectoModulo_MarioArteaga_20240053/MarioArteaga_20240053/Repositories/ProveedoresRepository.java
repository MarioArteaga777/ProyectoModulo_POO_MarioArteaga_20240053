package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Repositories;

import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Entities.ProveedoresEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProveedoresRepository extends JpaRepository<ProveedoresEntity,Long> {
}
