package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Models.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Null;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @EqualsAndHashCode
public class ProveedoresDTO {

    private Long providerID;

    @NotBlank(message = "El nombre del proveedor es obligatorio")
    private String providerName;

    @NotBlank(message = "El numero del proveedor es obligatorio")
    @NotNull
    private String  providerPhone;

    @NotBlank(message = "La direccion  del proveedor es obligatorio")
    @NotNull
    private String  providerAddress;

    @Email(message = "Debe de ser un correo valido")

    private String   providerEmail;

    @NotBlank(message = "El nombre del proveedor es obligatorio")
    @NotNull
    private String providerCode;


    private Long providerStatus ;

    private String providerComments;

}
