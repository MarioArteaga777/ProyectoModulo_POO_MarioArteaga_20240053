package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Controller;

import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Exceptions.ExceptionProveedorDuplicado;
import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Exceptions.ExceptionProveedorNoEncontrado;
import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Models.DTO.ProveedoresDTO;
import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Services.ProveedoresServices;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/apiProveedores")
public class ProveedoresController {
    @Autowired
    ProveedoresServices services;

    @GetMapping("/BuscarProveedores")
    public List<ProveedoresDTO>ObtenerProveedores(){
        return services.ObtenerProveedores();
    }
    @PostMapping("/AgregarProveedor")
    public ResponseEntity<?> nuevoProveedor(@Valid @RequestBody ProveedoresDTO json, HttpServletRequest request){
        try{
            ProveedoresDTO res = services.insertarProveedores(json);
            if (res== null){
            return ResponseEntity.badRequest().body(Map.of(
                    "status","Insertar Proveedor",
                    "errorType","VALIDATION_ERROR",
                    "message", "Los datos ingresados no son validos"
            ));
            }
            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                    "status","success",
                    "data",res
            ));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(
                    "status","Error",
                    "message","Error Al registrar Proveedor" + e.getMessage()
            ));

        }

    }
    @PutMapping("/EditarProveedor/{providerID}")
    public ResponseEntity<?> modificarProveedor(@PathVariable Long providerID, @Valid @RequestBody ProveedoresDTO json ,BindingResult bindingResult){
        if (bindingResult.hasErrors()){
            Map<String,String> errores = new HashMap<>();
            bindingResult.getFieldErrors().forEach(error ->
                    errores.put(error.getField(),error.getDefaultMessage()));
            return ResponseEntity.badRequest().body(errores);
        }
        try {
            ProveedoresDTO dto=services.ActualizarProveedor(providerID, json);
            return ResponseEntity.ok(dto);
        }
        catch (ExceptionProveedorDuplicado e){
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
                    "Error","Datos Duplicados",
                    "campo", e.getCampoDuplicado()
            ));
        }

    }
    @DeleteMapping("/EliminarProveedor/{providerID}")
    public ResponseEntity<Map<String,String>>Eliminar(@PathVariable Long providerID){
        boolean answer = services.EliminarProveedor(providerID);
        if (answer == true){
            return ResponseEntity.ok().body(Map.of(
                    "status","succes",
                    "message","Se elimino con exito"
            ));
        }else{
            return  ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(
                    "status","error",
                    "message","Error Interno al eliminar"
            ));
        }
    }


}
