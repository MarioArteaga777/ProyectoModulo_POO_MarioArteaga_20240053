package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053;

import io.github.cdimascio.dotenv.Dotenv;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarioArteaga20240053Application {

	public static void main(String[] args) {
		//Cargar variables del archivo .env al sistema

		Dotenv dotenv = Dotenv.configure().ignoreIfMissing().load();

		dotenv.entries().forEach(entry ->

				System.setProperty(entry.getKey(), entry.getValue())

		);

		SpringApplication.run(MarioArteaga20240053Application.class, args);
	}

}
