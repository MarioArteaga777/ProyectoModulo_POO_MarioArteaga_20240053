package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Exceptions;

public class ExceptionProveedorNoEncontrado extends RuntimeException {
    public ExceptionProveedorNoEncontrado(String message) {
        super(message);
    }
}
