package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Exceptions;

import lombok.Getter;

public class ExceptionProveedorDuplicado extends RuntimeException {
    public ExceptionProveedorDuplicado(String message) {
        super(message);
    }
    @Getter
    private String CampoDuplicado;
}
