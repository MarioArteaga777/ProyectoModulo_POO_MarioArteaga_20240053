package ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Services;

import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Entities.ProveedoresEntity;
import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Exceptions.ExceptionProveedorNoEncontrado;
import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Models.DTO.ProveedoresDTO;
import ProyectoModulo_MarioArteaga_20240053.MarioArteaga_20240053.Repositories.ProveedoresRepository;
import ch.qos.logback.classic.Logger;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.Response;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProveedoresServices {
    private static final org.slf4j.Logger log = LoggerFactory.getLogger(ProveedoresServices.class);
    @Autowired
    ProveedoresRepository repo;

    public List<ProveedoresDTO>ObtenerProveedores(){
        List<ProveedoresEntity> lista = repo.findAll();
        return lista.stream()
                .map(this::convertirADTO)
                .collect(Collectors.toList());
    }

    //Insertar Proveedor
  public ProveedoresDTO insertarProveedores(ProveedoresDTO data){
      if (data == null || data.getProviderName() == null || data.getProviderName().isEmpty()){
          throw new IllegalArgumentException("El campo nombre no debe estar vacio");
      }
      try{
          ProveedoresEntity entity = convertirAEntity(data);
          ProveedoresEntity guardarProveedor = repo.save(entity);
          return convertirADTO(guardarProveedor);
      }catch (Exception e){
         log.error("Error al registrar el proveedor" + e.getMessage());
          throw new ExceptionProveedorNoEncontrado("Error al encontrar el proveedor");

      }
  }
 //Actualizar
 public ProveedoresDTO ActualizarProveedor(Long providerID, @Valid ProveedoresDTO json){
        //Verificamos si existe
    ProveedoresEntity proveedorExiste = repo.findById(providerID).orElseThrow(() ->
            new ExceptionProveedorNoEncontrado("El Proveedor no encontrado"));
    //Convertir a Entity
    proveedorExiste.setProviderID(json.getProviderID());
    proveedorExiste.setProviderName(json.getProviderName());
    proveedorExiste.setProviderAddress(json.getProviderAddress());
    proveedorExiste.setProviderEmail(json.getProviderEmail());
    proveedorExiste.setProviderStatus(json.getProviderStatus());
    proveedorExiste.setProviderPhone(json.getProviderPhone());
    proveedorExiste.setProviderComments(json.getProviderComments());
    proveedorExiste.setProviderCode(json.getProviderCode());
    //Guardar los cambios hechos
    ProveedoresEntity Actualizacion = repo.save(proveedorExiste);
    //Convertir a dto
    return  convertirADTO(Actualizacion);

}
//Eliminar Proveedor
    public boolean EliminarProveedor(Long providerID) {
        try {
            ProveedoresEntity eliminarProveedor = repo.findById(providerID).orElse(null);
        if (eliminarProveedor != null) {
            repo.deleteById(providerID);
         return true;
        }
       else {
                System.out.println("Usuario No encontrado");
            }
         return false;
        } catch (Exception e) {
            System.out.println("Error al eliminar");
            return false;
        }
    }

    private ProveedoresDTO convertirADTO(ProveedoresEntity ent) {
        ProveedoresDTO dto = new ProveedoresDTO();
        dto.setProviderID(ent.getProviderID());
        dto.setProviderName(ent.getProviderName());
        dto.setProviderPhone(ent.getProviderPhone());
        dto.setProviderAddress(ent.getProviderAddress());
        dto.setProviderEmail(ent.getProviderEmail());
        dto.setProviderCode(ent.getProviderCode());
        dto.setProviderStatus(ent.getProviderStatus());
        dto.setProviderComments(ent.getProviderComments());

        return dto;
    }

    private ProveedoresEntity convertirAEntity(ProveedoresDTO data){
            ProveedoresEntity ent = new ProveedoresEntity();
        ent.setProviderID(data.getProviderID());
        ent.setProviderName(data.getProviderName());
        ent.setProviderPhone(data.getProviderPhone());
        ent.setProviderAddress(data.getProviderAddress());
        ent.setProviderEmail(data.getProviderEmail());
        ent.setProviderCode(data.getProviderCode());
        ent.setProviderStatus(data.getProviderStatus());
        ent.setProviderComments(data.getProviderComments());

        return ent;
    }
}
